import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False    # 用来正常显示负号

# 读取Excel数据
df = pd.read_excel('巨磁电阻实验记录.xlsx')

# 提取数据
B_down = df.iloc[:, 2]    # C列数据（磁场强度）
R_down = df.iloc[:, 3]    # D列数据（电阻值）
B_up = df.iloc[:, 7]      # H列数据（磁场强度）
R_up = df.iloc[:, 8]      # I列数据（电阻值）

# 创建图形
plt.figure(figsize=(12, 8))  # 增大图形尺寸

# 计算电阻的平均值和范围
R_mean = (R_down.mean() + R_up.mean()) / 2
R_range = max(R_down.max(), R_up.max()) - min(R_down.min(), R_up.min())

# 绘制两条曲线
plt.plot(B_down, R_down, 'r-', label='100mA到-100mA', linewidth=2, marker='o', markersize=4)
plt.plot(B_up, R_up, 'b--', label='-100mA到100mA', linewidth=2, marker='s', markersize=4)

# 设置图表标题和轴标签
plt.title('电阻随磁场强度变化关系图', fontsize=16)
plt.xlabel('磁场强度 (T)', fontsize=14)
plt.ylabel('电阻 (Ω)', fontsize=14)

# 添加图例
plt.legend(fontsize=12, loc='upper right')

# 添加网格
plt.grid(True, linestyle='--', alpha=0.3)

# 设置坐标轴范围
plt.xlim(-0.0035, 0.0035)
# 设置y轴范围，略微扩大范围使曲线更清晰
y_margin = R_range * 0.1  # 增加10%的边距
plt.ylim(R_mean - R_range/1.5, R_mean + R_range/1.3)

# 设置刻度字体大小
plt.xticks(fontsize=12)
plt.yticks(fontsize=12)

# 调整图形边距
plt.tight_layout()

# 保存图片，增加DPI使图像更清晰
plt.savefig('R_B_plot.png', dpi=300, bbox_inches='tight')

# 显示图片
plt.show() 