import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']  
plt.rcParams['axes.unicode_minus'] = False    

# 读取Excel数据
df = pd.read_excel('巨磁电阻传感器.xlsx')

# 提取数据并确保连续性
I1_up = df.iloc[:12, 0]    
U1_up = df.iloc[:12, 1]    
I1_down = df.iloc[11:22, 0]  
U1_down = df.iloc[11:22, 1]  

I2_up = df.iloc[:12, 3]    
U2_up = df.iloc[:12, 4]    
I2_down = df.iloc[11:22, 3]  
U2_down = df.iloc[11:22, 4]  

# 计算灵敏度
sensitivity1 = (U1_up.max() - U1_up.min()) / (I1_up.max() - I1_up.min()) * 1000  
sensitivity2 = (U2_up.max() - U2_up.min()) / (I2_up.max() - I2_up.min()) * 1000  

def create_plot(figsize=(12, 8)):
    """创建基本图形设置"""
    fig = plt.figure(figsize=figsize)
    plt.grid(True, linestyle='--', alpha=0.3)
    plt.xticks(np.arange(0, 201, 20), fontsize=12)
    plt.yticks(fontsize=12)
    return fig

# 图1：初始电压25mV的曲线
fig1 = create_plot()
plt.plot(I1_up, U1_up, 'r-', label='上升-初始电压25mV', linewidth=2, marker='o', markersize=5, markerfacecolor='white')
plt.plot(I1_down, U1_down, 'r--', label='下降-初始电压25mV', linewidth=2, marker='o', markersize=5, markerfacecolor='white')
plt.title('初始电压25mV的电压-电流特性曲线', fontsize=16, pad=15)
plt.xlabel('导线电流 (mA)', fontsize=14, labelpad=10)
plt.ylabel('电压表读数 (mV)', fontsize=14, labelpad=10)
plt.text(60, 25.5, f'灵敏度: {sensitivity1:.2f} μV/mA', 
         fontsize=12, color='red',
         bbox=dict(facecolor='white', edgecolor='red', alpha=0.8, pad=3))
plt.xlim(-5, 205)
plt.ylim(24.8, 27.2)
plt.legend(fontsize=11, loc='upper left')
plt.tight_layout()
plt.savefig('sensitivity_plot_25mV.png', dpi=300, bbox_inches='tight')
plt.close()

# 图2：初始电压89mV的曲线
fig2 = create_plot()
plt.plot(I2_up, U2_up, 'b-', label='上升-初始电压89mV', linewidth=2, marker='s', markersize=5, markerfacecolor='white')
plt.plot(I2_down, U2_down, 'b--', label='下降-初始电压89mV', linewidth=2, marker='s', markersize=5, markerfacecolor='white')
plt.title('初始电压89mV的电压-电流特性曲线', fontsize=16, pad=15)
plt.xlabel('导线电流 (mA)', fontsize=14, labelpad=10)
plt.ylabel('电压表读数 (mV)', fontsize=14, labelpad=10)
plt.text(60, 90.5, f'灵敏度: {sensitivity2:.2f} μV/mA', 
         fontsize=12, color='blue',
         bbox=dict(facecolor='white', edgecolor='blue', alpha=0.8, pad=3))
plt.xlim(-5, 205)
plt.ylim(89, 93)
plt.legend(fontsize=11, loc='upper left')
plt.tight_layout()
plt.savefig('sensitivity_plot_89mV.png', dpi=300, bbox_inches='tight')
plt.close()

# 图3：两条曲线合并（使用相对变化量）
fig3 = create_plot()

# 计算相对变化量
U1_up_relative = (U1_up - U1_up.iloc[0]) * 1000  
U1_down_relative = (U1_down - U1_up.iloc[0]) * 1000
U2_up_relative = (U2_up - U2_up.iloc[0]) * 1000
U2_down_relative = (U2_down - U2_up.iloc[0]) * 1000

# 绘制相对变化曲线
plt.plot(I1_up, U1_up_relative, 'r-', label='上升-初始电压25mV', linewidth=2, marker='o', markersize=5, markerfacecolor='white')
plt.plot(I1_down, U1_down_relative, 'r--', label='下降-初始电压25mV', linewidth=2, marker='o', markersize=5, markerfacecolor='white')
plt.plot(I2_up, U2_up_relative, 'b-', label='上升-初始电压89mV', linewidth=2, marker='s', markersize=5, markerfacecolor='white')
plt.plot(I2_down, U2_down_relative, 'b--', label='下降-初始电压89mV', linewidth=2, marker='s', markersize=5, markerfacecolor='white')

plt.title('不同初始磁场下的电压变化量对比', fontsize=16, pad=15)
plt.xlabel('导线电流 (mA)', fontsize=14, labelpad=10)
plt.ylabel('电压变化量 (μV)', fontsize=14, labelpad=10)

# 添加灵敏度标注
plt.text(60, 500, f'灵敏度1: {sensitivity1:.2f} μV/mA', 
         fontsize=12, color='red',
         bbox=dict(facecolor='white', edgecolor='red', alpha=0.8, pad=3))
plt.text(60, 2000, f'灵敏度2: {sensitivity2:.2f} μV/mA', 
         fontsize=12, color='blue',
         bbox=dict(facecolor='white', edgecolor='blue', alpha=0.8, pad=3))

plt.xlim(-5, 205)
plt.ylim(-100, 3600)
plt.legend(fontsize=11, loc='upper left')
plt.tight_layout()
plt.savefig('sensitivity_plot_combined.png', dpi=300, bbox_inches='tight')
plt.close() 